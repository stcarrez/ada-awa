from test_support import *

run('testme', ["testme47.tmplt"])
