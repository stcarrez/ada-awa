from test_support import *

build_and_run('cache_control_header');
