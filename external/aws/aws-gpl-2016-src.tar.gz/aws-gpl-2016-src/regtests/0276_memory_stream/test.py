from test_support import *

build('memstr')
run('memstr')
