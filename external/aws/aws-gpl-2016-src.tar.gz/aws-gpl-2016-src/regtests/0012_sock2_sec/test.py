from test_support import *

build_and_run('sock2_sec');
