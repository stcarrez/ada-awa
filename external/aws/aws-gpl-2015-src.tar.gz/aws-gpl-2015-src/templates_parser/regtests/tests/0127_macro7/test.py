from test_support import *
run('testme', ["main.thtml", "-M"])
