from test_support import *

run('testme', ["testme14.tmplt"])
