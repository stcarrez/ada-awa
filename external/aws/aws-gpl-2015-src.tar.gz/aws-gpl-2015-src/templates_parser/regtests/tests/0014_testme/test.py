from test_support import *

run('testme', ["testme25.tmplt"])
run('print_tree', ["testme25.tmplt"])
