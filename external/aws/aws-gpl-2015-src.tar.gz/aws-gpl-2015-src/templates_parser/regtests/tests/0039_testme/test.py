from test_support import *

run('testme', ["testme34.tmplt"])
