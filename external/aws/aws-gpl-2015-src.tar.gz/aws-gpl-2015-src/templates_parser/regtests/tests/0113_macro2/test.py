from test_support import *

run('print_tree', ["macro.tmplt"])
run('testme', ["macro.tmplt"])
