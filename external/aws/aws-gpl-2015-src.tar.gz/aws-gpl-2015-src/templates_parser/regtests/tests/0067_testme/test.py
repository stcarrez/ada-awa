from test_support import *

run('testme', ["testme67.tmplt"])
