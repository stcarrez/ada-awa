from test_support import *

run('testme', ["blocks7.tmplt"])
