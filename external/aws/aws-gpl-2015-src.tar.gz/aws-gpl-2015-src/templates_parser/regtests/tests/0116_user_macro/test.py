from test_support import *

gprbuild('user_macro')
run('user_macro')
