from test_support import *
import os

build_and_run('page_server');
