from test_support import *

build_and_run('dispatch_with_unregister');
