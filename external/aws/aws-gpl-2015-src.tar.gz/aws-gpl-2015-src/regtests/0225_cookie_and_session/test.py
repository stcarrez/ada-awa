from test_support import *
import time

build_and_run('cookie_session')
