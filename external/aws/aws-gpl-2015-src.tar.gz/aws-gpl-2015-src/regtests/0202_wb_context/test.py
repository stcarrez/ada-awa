from test_support import *

build_and_run('web_blocks_ctx');
