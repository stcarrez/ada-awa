from test_support import *

build_and_run('stream_response2');
