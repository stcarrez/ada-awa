from test_support import *
import os

build_and_run('cache_cont_page_server');
