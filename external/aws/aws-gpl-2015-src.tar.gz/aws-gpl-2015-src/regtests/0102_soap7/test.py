from test_support import *

build_and_run('soap7');
