from test_support import *

build_and_run('socket_send_buffer');
