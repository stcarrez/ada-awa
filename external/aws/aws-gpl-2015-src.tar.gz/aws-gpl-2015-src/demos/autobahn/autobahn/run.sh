# requires autobahn to be installed

wstest -m fuzzingclient -s aws.json
