/* ===========================================================
 * en.js
 * English translation for Trumbowyg
 * http://alex-d.github.com/Trumbowyg
 * ===========================================================
 * Author : Alexandre Demode (Alex-D)
 *          Twitter : @AlexandreDemode
 *          Website : alex-d.fr
 */

/**
 * English is the default language of Trumbowyg,
 * you don't need to include any file :)
 */
