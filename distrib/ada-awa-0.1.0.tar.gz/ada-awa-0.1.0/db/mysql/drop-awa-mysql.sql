/* Copied from ./db/mysql/awa-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `acl`;
DROP TABLE IF EXISTS `session`;
DROP TABLE IF EXISTS `access_key`;
DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `email`;
DROP TABLE IF EXISTS `comments`;
DROP TABLE IF EXISTS `blog_post`;
DROP TABLE IF EXISTS `blog`;
/* Copied from /home/ciceron/work/pam/pam/awa/ado/db/mysql/ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `entity_type`;
DROP TABLE IF EXISTS `sequence`;
