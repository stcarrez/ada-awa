/* Copied from /home/ciceron/work/pam/pam/awa/awa/db/sqlite/awa-drop-sqlite.sql*/
/* File generated automatically by dynamo */
drop table if exists `ACL`;
drop table if exists `session`;
drop table if exists `access_key`;
drop table if exists `user`;
drop table if exists `email`;
drop table if exists `COMMENTS`;
/* Copied from /home/ciceron/work/pam/pam/awa/ado/db/sqlite/ado-drop-sqlite.sql*/
/* File generated automatically by dynamo */
drop table if exists `entity_type`;
drop table if exists `sequence`;
