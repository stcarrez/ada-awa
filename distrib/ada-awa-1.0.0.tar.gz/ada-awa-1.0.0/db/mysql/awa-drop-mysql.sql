/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_user`;
DROP TABLE IF EXISTS `awa_session`;
DROP TABLE IF EXISTS `awa_email`;
DROP TABLE IF EXISTS `awa_access_key`;
DROP TABLE IF EXISTS `awa_acl`;
DROP TABLE IF EXISTS `awa_queue`;
DROP TABLE IF EXISTS `awa_message_type`;
DROP TABLE IF EXISTS `awa_message`;
