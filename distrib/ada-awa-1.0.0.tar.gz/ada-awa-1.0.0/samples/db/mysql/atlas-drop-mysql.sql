/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `atlas_review`;
DROP TABLE IF EXISTS `mblog`;
