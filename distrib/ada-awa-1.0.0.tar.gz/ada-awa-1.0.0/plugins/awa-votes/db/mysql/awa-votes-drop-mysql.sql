/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_vote`;
DROP TABLE IF EXISTS `awa_rating`;
