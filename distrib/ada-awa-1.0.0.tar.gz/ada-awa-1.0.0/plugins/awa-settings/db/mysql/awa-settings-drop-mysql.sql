/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_user_setting`;
DROP TABLE IF EXISTS `awa_setting`;
DROP TABLE IF EXISTS `awa_global_setting`;
