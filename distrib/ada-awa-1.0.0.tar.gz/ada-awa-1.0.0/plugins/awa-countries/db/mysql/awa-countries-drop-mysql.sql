/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_region`;
DROP TABLE IF EXISTS `awa_country_neighbor`;
DROP TABLE IF EXISTS `awa_country`;
DROP TABLE IF EXISTS `awa_city`;
