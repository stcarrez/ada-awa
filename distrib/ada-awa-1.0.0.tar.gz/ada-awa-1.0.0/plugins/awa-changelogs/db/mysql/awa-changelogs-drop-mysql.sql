/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_changelog`;
