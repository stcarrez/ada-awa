/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_question`;
DROP TABLE IF EXISTS `awa_answer`;
