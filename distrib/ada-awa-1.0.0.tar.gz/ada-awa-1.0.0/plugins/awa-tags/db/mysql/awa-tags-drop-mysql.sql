/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_tagged_entity`;
DROP TABLE IF EXISTS `awa_tag`;
