/* Copied from ./db/regtests/mysql/ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `allocate`;
DROP TABLE IF EXISTS `test_user`;
DROP TABLE IF EXISTS `TEST_COMMENTS`;
/* Copied from /home/ciceron/work/pam/pam/awa/ado/db/mysql/ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `entity_type`;
DROP TABLE IF EXISTS `sequence`;
