/* Copied from ./db/mysql/ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `entity_type`;
DROP TABLE IF EXISTS `sequence`;
