/* Copied from ado-drop-sqlite.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `sequence`;
