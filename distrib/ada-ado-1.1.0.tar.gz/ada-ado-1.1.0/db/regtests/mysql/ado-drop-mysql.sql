/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `test_table`;
DROP TABLE IF EXISTS `test_nullable_table`;
DROP TABLE IF EXISTS `test_user`;
DROP TABLE IF EXISTS `allocate`;
DROP TABLE IF EXISTS `test_image`;
DROP TABLE IF EXISTS `TEST_COMMENTS`;
