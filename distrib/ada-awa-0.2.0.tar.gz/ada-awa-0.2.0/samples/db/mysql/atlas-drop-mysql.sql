/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `mblog`;
