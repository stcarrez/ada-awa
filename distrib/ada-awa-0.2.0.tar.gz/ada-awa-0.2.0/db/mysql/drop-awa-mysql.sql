/* Copied from awa-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `session`;
DROP TABLE IF EXISTS `email`;
DROP TABLE IF EXISTS `awa_queue`;
DROP TABLE IF EXISTS `awa_message_type`;
DROP TABLE IF EXISTS `awa_message`;
DROP TABLE IF EXISTS `acl`;
DROP TABLE IF EXISTS `access_key`;
/* Copied from awa-blogs-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `blog_post`;
DROP TABLE IF EXISTS `blog`;
/* Copied from awa-images-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_image_folder`;
DROP TABLE IF EXISTS `awa_image`;
/* Copied from awa-storages-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_store_local`;
DROP TABLE IF EXISTS `awa_storage_data`;
DROP TABLE IF EXISTS `awa_storage`;
/* Copied from awa-workspaces-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `workspace_member`;
DROP TABLE IF EXISTS `workspace`;
/* Copied from awa-comments-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `comments`;
/* Copied from ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `sequence`;
DROP TABLE IF EXISTS `entity_type`;
