/* Copied from awa-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `workspace_member`;
DROP TABLE IF EXISTS `workspace`;
DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `session`;
DROP TABLE IF EXISTS `email`;
DROP TABLE IF EXISTS `comments`;
DROP TABLE IF EXISTS `blog_post`;
DROP TABLE IF EXISTS `blog`;
DROP TABLE IF EXISTS `awa_store_local`;
DROP TABLE IF EXISTS `awa_storage_data`;
DROP TABLE IF EXISTS `awa_storage`;
DROP TABLE IF EXISTS `awa_queue`;
DROP TABLE IF EXISTS `awa_message_type`;
DROP TABLE IF EXISTS `awa_message`;
DROP TABLE IF EXISTS `awa_image_folder`;
DROP TABLE IF EXISTS `awa_image`;
DROP TABLE IF EXISTS `acl`;
DROP TABLE IF EXISTS `access_key`;
/* Copied from ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `sequence`;
DROP TABLE IF EXISTS `entity_type`;
