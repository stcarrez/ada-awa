/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_store_local`;
DROP TABLE IF EXISTS `awa_storage_data`;
DROP TABLE IF EXISTS `awa_storage`;
