/* Copied from awa-workspaces-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `workspace_member`;
DROP TABLE IF EXISTS `workspace`;
