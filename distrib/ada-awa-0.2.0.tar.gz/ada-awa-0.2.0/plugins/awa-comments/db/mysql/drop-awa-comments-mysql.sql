/* Copied from awa-comments-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `comments`;
