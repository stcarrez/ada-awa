/* Copied from awa-blogs-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `blog_post`;
DROP TABLE IF EXISTS `blog`;
