/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_workspace_member`;
DROP TABLE IF EXISTS `awa_workspace_feature`;
DROP TABLE IF EXISTS `awa_workspace`;
