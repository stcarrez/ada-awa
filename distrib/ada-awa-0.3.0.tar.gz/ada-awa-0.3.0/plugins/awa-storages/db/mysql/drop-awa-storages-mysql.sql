/* Copied from awa-storages-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_store_local`;
DROP TABLE IF EXISTS `awa_storage_folder`;
DROP TABLE IF EXISTS `awa_storage_data`;
DROP TABLE IF EXISTS `awa_storage`;
/* Copied from awa-workspaces-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_workspace_member`;
DROP TABLE IF EXISTS `awa_workspace_feature`;
DROP TABLE IF EXISTS `awa_workspace`;
/* Copied from ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `sequence`;
DROP TABLE IF EXISTS `entity_type`;
/* Copied from awa-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_user`;
DROP TABLE IF EXISTS `awa_session`;
DROP TABLE IF EXISTS `awa_email`;
DROP TABLE IF EXISTS `awa_access_key`;
DROP TABLE IF EXISTS `awa_acl`;
DROP TABLE IF EXISTS `awa_queue`;
DROP TABLE IF EXISTS `awa_message_type`;
DROP TABLE IF EXISTS `awa_message`;
