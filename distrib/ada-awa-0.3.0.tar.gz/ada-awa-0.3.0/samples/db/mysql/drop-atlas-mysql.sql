/* Copied from atlas-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `mblog`;
/* Copied from awa-votes-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_vote`;
DROP TABLE IF EXISTS `awa_rating`;
/* Copied from awa-questions-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_question`;
DROP TABLE IF EXISTS `awa_answer`;
/* Copied from awa-images-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_image`;
/* Copied from awa-storages-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_store_local`;
DROP TABLE IF EXISTS `awa_storage_folder`;
DROP TABLE IF EXISTS `awa_storage_data`;
DROP TABLE IF EXISTS `awa_storage`;
/* Copied from awa-blogs-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_post`;
DROP TABLE IF EXISTS `awa_blog`;
/* Copied from awa-workspaces-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_workspace_member`;
DROP TABLE IF EXISTS `awa_workspace_feature`;
DROP TABLE IF EXISTS `awa_workspace`;
/* Copied from awa-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `awa_user`;
DROP TABLE IF EXISTS `awa_session`;
DROP TABLE IF EXISTS `awa_email`;
DROP TABLE IF EXISTS `awa_access_key`;
DROP TABLE IF EXISTS `awa_acl`;
DROP TABLE IF EXISTS `awa_queue`;
DROP TABLE IF EXISTS `awa_message_type`;
DROP TABLE IF EXISTS `awa_message`;
/* Copied from ado-drop-mysql.sql*/
/* File generated automatically by dynamo */
DROP TABLE IF EXISTS `sequence`;
DROP TABLE IF EXISTS `entity_type`;
